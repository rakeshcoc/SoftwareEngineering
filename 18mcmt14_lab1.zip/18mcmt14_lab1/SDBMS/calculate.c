
rec calculate(rec r)
{
 r.average=(r.marks[0]+r.marks[1]+r.marks[2]+r.marks[3]+r.marks[4])/5;
 if(r.average >= 40.0)
  r.result='p';
 else
  r.result='f';
 return r; 
}

