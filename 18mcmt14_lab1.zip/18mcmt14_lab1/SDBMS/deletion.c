void delete(int roll)
{
 
 FILE *f1 = fopen("Input_File.txt","r");
 FILE *f2 = fopen("Temp.txt","w");
 add *a=(add *)malloc(sizeof(add));
 rec *r=(rec *)malloc(sizeof(rec));
 int flag=0; 
while(!feof(f1)) while(!feof(f1))
 {
  fread(a,sizeof(add),1,f1);
  fread(r,sizeof(rec),1,f1);
  if(r->roll_No==roll)
   {
    flag=1;
    break;
   }
 }
 if(flag==0)
  {
   printf("\t\t\nRoll no. not yet enrolled. So, can't delete\n");
   return;
  }
 fclose(f1);
 FILE *f3 = fopen("Input_File.txt","r");


 {
   fread(a,sizeof(add),1,f3);
   fread(r,sizeof(rec),1,f3);  
   printf("Check1\n");
   if(r->roll_No != roll)
   {
    fwrite(a,sizeof(add),1,f2);
    fwrite(r,sizeof(rec),1,f2);
   }
   
 }
  printf("Check2\n");
 fclose(f3);
 fclose(f2);
 remove("Input_File.txt");
 rename("Temp.txt","Input_File.txt");
 printf("Deletion Done\n");
}
