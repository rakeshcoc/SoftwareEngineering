void input()
{
int n;
 FILE *f=fopen("Input_File.txt","a");
 printf("How many students\n");
 scanf("%d",&n);
 add *a=(add *)malloc(sizeof(add));
 rec *r=(rec *)malloc(sizeof(rec));
 for(int i=0;i<n;i++)
 {
  printf("\n\n\t\tEnter details of student %d\n\n",i+1);
  printf("Enter Name :");
  scanf("%s",r->name);
  printf("Enter RollNumber :");
  scanf("%d",&r->roll_No);
  if(validRoll(r->roll_No))
  {
   i--;
   continue;
  }
  printf("Enter City Name :");
  scanf("%s",a->city);
  printf("Enter PinCode :");
  scanf("%lu",&a->pincode);
  printf("Enter House No. :");
  scanf("%d",&a->House_No);
  printf("\nEnter Marks of 5 subjects:  ");
  for(int j=0;j<5;j++)
  {
   scanf("%d",&r->marks[j]);
   if(r->marks[j]<=0 || r->marks[j]>=100)
    {
     printf(" Renter marks b/w 0 to 100:");
     j--;
    }
  }
  
  *r=calculate(*r);
  fwrite(a,sizeof(add),1,f);
  fwrite(r,sizeof(rec),1,f);
 }
 fclose(f);
}
