/*Program For Student Database Management System
  Author: Rakesh Prasad
  Date  : 16/02/2019
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "structure.c"
#include "calculate.c"
#include "validation.c"
#include "deletion.c"
#include "input.c"
#include "output.c"
#include "printRecord.c"
#include "query.c"

void main()
{
 
 while(1)
 {
  printf("\n\n \t\tEnter 1 for Input, 2 for Output, 3 for Query ,4 for exit\n\n\n");
  int n;
  scanf("%d",&n);
  switch(n)
  {
   case 1:
    input();
   break;
   case 2:
    output();
   break;
   case 3:
    query();
   break; 
   case 4:
    exit(1);
   break;
   default:
    printf("Wrong Choice\n");
    exit(1);
   break;
  }
 }
}
