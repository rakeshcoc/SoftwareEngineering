void print_Record(add a,rec r)
{
 printf("Name:%s RollNumber:%d\nCity:%s     HouseNo:%d     PinCode:%lu \nMarks1:%d Marks2:%d Marks3:%d Marks4:%d Marks5:%d\nAverage:%f \nResult:%c \n\n\n",r.name,r.roll_No,a.city,a.House_No,a.pincode,r.marks[0],r.marks[1],r.marks[2],r.marks[3],r.marks[4],r.average,r.result);
}
