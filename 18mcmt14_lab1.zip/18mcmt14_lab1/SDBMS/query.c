
void query()
{
 
 add *a=(add *)malloc(sizeof(add));
 rec *r=(rec *)malloc(sizeof(rec));
  printf("\n\t\t\tPlease Enter for menu\n\n");
  printf("\n1: for search with result\n2: for search with rollno \n3: For search with average\n4:To delete record on basis of roll no  :");
  int n;
  scanf("%d",&n);
  if(n==1)
  {
   FILE *f=fopen("Input_File.txt","r");
   char pass_fail;
   printf("\nEnter 'p' for pass student record and 'f' for fail student record :");
   scanf("%s",&pass_fail);
   while(!feof(f))
   {
    fread(a,sizeof(add),1,f);
    fread(r,sizeof(rec),1,f);
    if(pass_fail==r->result)
    {
     if(!feof(f))
     {
      printf("\n");
      print_Record(*a,*r);
     }  
    }    
   }
   fclose(f);
  }
  if(n==2)
  {
   int Roll_No;
   FILE *f=fopen("Input_File.txt","r");
   printf("\nEnter RollNo. of student :");
   scanf("%d\n\n",&Roll_No);
   while(!feof(f))
   {
    fread(a,sizeof(add),1,f);
    fread(r,sizeof(rec),1,f);
    if(Roll_No==r->roll_No)
    {
     if(!feof(f))
     print_Record(*a,*r); 
     break;
    }    
   }
   fclose(f);
  }
  if(n==3)
  {
   float avg;
   FILE *f1=fopen("Input_File.txt","r");
   printf("\nEnter atleast Average marks of student whose records to be printed:");
   scanf("%f",&avg);
   while(!feof(f1))
   {
    fread(a,sizeof(add),1,f1);
    fread(r,sizeof(rec),1,f1);
    if(avg <= r->average)
    {
     printf("\n");
     if(!feof(f1))
     print_Record(*a,*r); 
    }    
   }
   fclose(f1);
  }
  if(n==4)
  {
   int roll;
   printf("\nEnter roll no of enrolled record\n");
   scanf("%d",&roll);
   delete(roll); 
  }
  else
   printf("Wrong Choice\n");
}
