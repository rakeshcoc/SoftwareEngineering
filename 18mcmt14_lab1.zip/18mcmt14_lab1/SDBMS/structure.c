typedef struct address
{
 char city[20];
 long int pincode;
 int House_No;
}add;
typedef struct record
{
 char name[20];
 int roll_No;
 int marks[5];
 float average;
 char result;
}rec;
