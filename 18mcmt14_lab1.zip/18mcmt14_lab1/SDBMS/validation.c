int validRoll(int roll)
{
 FILE *f=fopen("Input_File.txt","r");
 add *a=(add *)malloc(sizeof(add));
 rec *r=(rec *)malloc(sizeof(rec));
 while(!feof(f))
 {
  fread(a,sizeof(add),1,f);
  fread(r,sizeof(rec),1,f);
  if(r->roll_No==roll)
   {
    printf("This roll number record already present. PLz Renter\n");
    return 1;
   }
  else
   return 0;
 }
}
